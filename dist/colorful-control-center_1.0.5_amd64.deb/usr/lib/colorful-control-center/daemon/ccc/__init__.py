# SPDX-License-Identifier: GPL-2.0+
"""colorful-control-center daemon internals."""
